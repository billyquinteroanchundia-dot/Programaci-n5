import express from 'express';
import cors from 'cors';
import bodyParser from 'body-parser';
import indexRoutes from '../routes/index.routes.js';
import dbConnection from '../database/config.js';

export default class Server {
    constructor() {
       this.app = express();
       this.port = process.env.PORT || '3000';
       this.generalRoutes = '/api/';

       // Conectar a base de datos
       this.conectarDB();

       //Middleware
       this.middleware();
       //Rutas
       this.routes();
    }

    async conectarDB() {
        await dbConnection();
    }
    middleware() {
        //cors
        this.app.use(cors());
        //lectura y parseo del body
        this.app.use(bodyParser.json());
        //directorio publico
        this.app.use(express.static('public'));
    } 
    routes() {
        //localhost:3000/api/ejemplo
        this.app.use(this.generalRoutes, indexRoutes);
    }  
    listen() {
        this.app.listen(this.port, () => {
            console.log('Servidor corriendo en puerto ' + this.port);
        });
    } 
}       
