import {Router} from 'express';
import {
    getEjemplo,
    getEjemploById,
    postEjemplo,
    putEjemplo,
    deleteEjemplo
} from '../controllers/ejemplo.controller.js';

const ejemplo = Router();

ejemplo.get('/', getEjemplo);
ejemplo.get('/:id', getEjemploById);
ejemplo.post('/', postEjemplo);
ejemplo.put('/:id', putEjemplo);
ejemplo.delete('/:id', deleteEjemplo);

export default ejemplo;