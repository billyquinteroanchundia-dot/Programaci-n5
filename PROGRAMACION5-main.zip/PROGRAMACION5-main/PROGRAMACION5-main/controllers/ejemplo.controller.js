export const getEjemplo = (req, res) => {
    res.json({
        msg: 'get API'
    });
};

export const getEjemploById = (req, res) => {
    const {id} = req.params;
    res.json({  
        msg: 'get API',
        id
    });
};

export const postEjemplo = (req, res) => {
    const body = req.body;
    res.json({
        msg: 'post API',
        body
    });
};

export const putEjemplo = (req, res) => {
    const {id} = req.params;
    const body = req.body;
    res.json({
        msg: 'put API',
        id,
        body
    });
};

export const deleteEjemplo = (req, res) => {
    const {id} = req.params;
    res.json({
        msg: 'delete API',
        id
    });
};
